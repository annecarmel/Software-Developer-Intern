﻿using EmployeeManagementApp.Models;
using EmployeeManagementApp.DataAccess;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace EmployeeManagementApp.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly EmployeeRepository _employeeRepository;

        public EmployeeController(IConfiguration configuration)
        {
            _employeeRepository = new EmployeeRepository(configuration);
        }

        [HttpGet]
        public IActionResult Employee()
        {
            var model = new EmployeePageViewModel
            {
                Employee = new EmployeeViewModel(),
                EmployeeList = _employeeRepository.GetAllEmployees()
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult SaveEmployee(EmployeeViewModel employee)
        {
            if (ModelState.IsValid)
            {
                _employeeRepository.AddEmployee(employee);

                TempData["SuccessMessage"] = "Employee saved successfully!";
                return RedirectToAction("Employee");
            }

            var model = new EmployeePageViewModel
            {
                Employee = employee,
                EmployeeList = _employeeRepository.GetAllEmployees()
            };

            return View("Employee", model);
        }
    }
}
