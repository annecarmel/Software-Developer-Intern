﻿using EmployeeManagementApp.Models;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace EmployeeManagementApp.DataAccess
{
    public class EmployeeRepository
    {
        private readonly string _connectionString;

        public EmployeeRepository(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public void AddEmployee(EmployeeViewModel employee)
        {
            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                string query = @"INSERT INTO Employees 
                                (EmployeeName, DateOfBirth, Age, Gender, PhoneNumber, Email, AddressLine1, AddressLine2, PinCode, District, State)
                                VALUES 
                                (@EmployeeName, @DateOfBirth, @Age, @Gender, @PhoneNumber, @Email, @AddressLine1, @AddressLine2, @PinCode, @District, @State)";

                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@EmployeeName", employee.EmployeeName);
                cmd.Parameters.AddWithValue("@DateOfBirth", employee.DateOfBirth);
                cmd.Parameters.AddWithValue("@Age", employee.Age);
                cmd.Parameters.AddWithValue("@Gender", employee.Gender);
                cmd.Parameters.AddWithValue("@PhoneNumber", employee.PhoneNumber);
                cmd.Parameters.AddWithValue("@Email", employee.Email);
                cmd.Parameters.AddWithValue("@AddressLine1", employee.AddressLine1);
                cmd.Parameters.AddWithValue("@AddressLine2", employee.AddressLine2);
                cmd.Parameters.AddWithValue("@PinCode", employee.PinCode);
                cmd.Parameters.AddWithValue("@District", employee.District);
                cmd.Parameters.AddWithValue("@State", employee.State);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public List<EmployeeViewModel> GetAllEmployees()
        {
            List<EmployeeViewModel> employees = new List<EmployeeViewModel>();

            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                string query = "SELECT EmployeeId, EmployeeName, DateOfBirth, Age, Gender, PhoneNumber, Email, AddressLine1, AddressLine2, PinCode, District, State FROM Employees";

                MySqlCommand cmd = new MySqlCommand(query, conn);
                conn.Open();

                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        employees.Add(new EmployeeViewModel
                        {
                            EmployeeId = reader.GetInt32("EmployeeId"),
                            EmployeeName = reader.GetString("EmployeeName"),
                            DateOfBirth = reader.GetDateTime("DateOfBirth"),
                            Age = reader.GetInt32("Age"),
                            Gender = reader.GetString("Gender"),
                            PhoneNumber = reader.GetString("PhoneNumber"),
                            Email = reader.GetString("Email"),
                            AddressLine1 = reader.GetString("AddressLine1"),
                            AddressLine2 = reader.GetString("AddressLine2"),
                            PinCode = reader.GetString("PinCode"),  // Throwed error earlier, getting confused between int and string
                            District = reader.GetString("District"),
                            State = reader.GetString("State")
                        });
                    }
                }
            }

            return employees;
        }
    }
}
