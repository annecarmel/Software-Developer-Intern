﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EmployeeManagementApp.Models
{
    public class EmployeeViewModel
    {
        public int EmployeeId { get; set; }

        [Required]
        public string EmployeeName { get; set; }

        [DataType(DataType.Date)]
        public DateTime? DateOfBirth { get; set; }

        public int Age { get; set; }

        public string Gender { get; set; }

        [Phone]
        public string PhoneNumber { get; set; }

        [EmailAddress]
        public string Email { get; set; }

        public string AddressLine1 { get; set; }

        public string AddressLine2 { get; set; }

        public string PinCode { get; set; }

        public string District { get; set; }

        public string State { get; set; }

        // List to hold multiple employees for display (throwed error earlier)
        public List<EmployeeViewModel> EmployeeList { get; set; } = new List<EmployeeViewModel>();
    }
}
